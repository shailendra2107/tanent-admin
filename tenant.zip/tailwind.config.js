/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        "purple": "#1B52B1",
        "dark-purple": "#05113E",
        "light-white": "rgba(255,255,255,0.17)",
        "dark": "#252733",
        "light": "#9FA2B4",
        "light-blue": "#0191D0",
        "lightGray": "#9E9A9A",
        "light-smoke": "#f5f5f5",
        "darkest-blue": "#223354",
        "green": "#3BB900",
        "light-green": "#ECFBE6"
      },
      boxShadow: {
        'purple': '0px 4px 9px rgba(2, 31, 140, 0.36)',
        'light-purple': '0px 4px 12px rgba(55, 81, 255, 0.24)',
        'light-gray': '0px 9px 16px rgba(159, 162, 191, 0.18), 0px 2px 2px rgba(159, 162, 191, 0.32)',
      },
      fontSize: {
        "md": "16px"
      },
      outlineColor: {
        "dark-purple": "#05113E",
      },

      backgroundColor: {
        "green-linear": "#35CD3A",
      },
      backgroundImage: {
        "red-linear": "linear-gradient(180deg, #FFBF96 0%, #FE7096 100%)",

        "blue-linear": "linear-gradient(180deg, #90CAF9 0%, rgba(4, 126, 223, 0.9) 100%)",
        "orange-linear": "linear-gradient(180deg, #FFA100 0%, #FFC056 100%)"
      }
    },
  },
  plugins: [],
}
