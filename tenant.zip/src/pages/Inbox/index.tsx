import React from 'react'

const Inbox = () => {
  return (
    <div>sssssssssss</div>
  )
}

export default Inbox