import React from 'react'

const Outstanding = () => {
  return (
    <div>Outstanding</div>
  )
}

export default Outstanding