import React from 'react'
import ButtonWrapper from '../../../../components/Form/Buttons/ButtonWrapper'
import DatePicker from '../../../../components/Form/Inputs/DatePicker'
import Input from '../../../../components/Form/Inputs/Input'
import Select from '../../../../components/Form/Inputs/Select'

const PayOutstanding = () => {
  return (
    <div>
      <div className="text-darkest-blue font-semibold text-md  border-b-2 px-5 pt-5 pb-3">
        Pay Outstandings
      </div>
      <div className="p-5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-center justify-between">
          <label className='col-span-1 md:col-span-1 text-black font-normal text-sm'>Select Card :</label>
          <Select classNames='col-span-1 md:col-span-2' />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-center justify-between my-4">
          <label className='col-span-1 text-black font-normal text-sm'>Select Card :</label>
          <Input classNames="col-span-1 md:col-span-2" mode='hidden' />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-center justify-between my-4">
          <label className='col-span-1 text-black font-normal text-sm'>Select Card :</label>
          <DatePicker classNames="col-span-1 md:col-span-2" />
        </div>
        <div className="grid grid-cols-1">
          <ButtonWrapper type='button' text='Pay Now' classNames='bg-purple rounded-md py-2 mt-7 text-white shadow-light-purple' />
        </div>
      </div>
    </div>
  )
}

export default PayOutstanding