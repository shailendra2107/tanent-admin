import React, { useState } from 'react'
import ButtonWrapper from '../../../../components/Form/Buttons/ButtonWrapper'
import DatePicker from '../../../../components/Form/Inputs/DatePicker'
import Select from '../../../../components/Form/Inputs/Select'
import calander from '../../../../assets/Icons/book-aminity.svg'
import DataTable from '../../../../components/Tables/DataTable'
import { ServiceRequest } from '../../../../components/Tables/Columns'
import { serviceData } from '../../data'

const AminityBooking = () => {
  const [bookingShow, setBookingShow] = useState<boolean>(false)
  return (
    <div>
      <div className="text-darkest-blue flex justify-between items-center font-semibold text-md  border-b-2 p-5">
        <span>Aminity Booking</span>
        <div className="">
          <ButtonWrapper
            classNames={`flex items-center text-sm border border-purple  font-bold rounded-md px-5 py-2 ${bookingShow ? 'text-white bg-purple' : 'text-purple'}`}
            text={!bookingShow ? 'Boooking History' : 'Boook Aminity'}
            onHandleClick={() => setBookingShow(!bookingShow)}
            svgIcon={bookingShow && calander}
          />
        </div>
      </div>
      {
        !bookingShow ?
          <div className="grid grid-cols-1 md:grid-cols-7 gap-5 p-5">
            <div className="col-span-2 flex flex-col md:flex-row items-center ">
              <label className='text-black font-normal text-sm mr-3'>
                Select Aminity
              </label>
              <Select />
            </div>
            <div className="col-span-2 flex flex-col md:flex-row items-center ">
              <label className='text-black font-normal text-sm mr-3'>
                Select Date
              </label>
              <DatePicker type='date' />
            </div>
            <div className="col-span-2 flex flex-col md:flex-row items-center ">
              <label className='text-black font-normal text-sm mr-3'>
                Select Time Slot
              </label>
              <DatePicker type='time' />
            </div>
            <div className="col-span-1">
              <div className="">
                <ButtonWrapper svgIcon={calander} classNames='flex items-center text-sm border border-purple text-white bg-purple font-bold rounded-md px-5 py-2' text='Boook Aminity' onHandleClick={() => setBookingShow(!bookingShow)} />
              </div>
            </div>
          </div> :
          <div className="">
            <DataTable columns={ServiceRequest} dataSource={serviceData} />
          </div>
      }
    </div>
  )
}

export default AminityBooking