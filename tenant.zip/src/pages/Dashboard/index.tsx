import React from 'react';
import AminityBooking from './Components/AminityBooking';
import CardSection from './Components/CardSection';
import PayOutstanding from './Components/PayOutstanding';
import ServicesRequest from './Components/ServicesRequest';

const Home: React.FC = () => {
  return (
    <main className="">
      <CardSection />
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-7 gap-5 px-5">
        <div className="col-span-1 md:col-span-2 bg-white shadow-light-gray">
          <PayOutstanding />
        </div>
        <div className="col-span-1 md:col-span-5 bg-white shadow-light-gray">
          <ServicesRequest />
        </div>
      </div>
      <div className="p-5">
        <div className="shadow-light-gray bg-white">
          <AminityBooking />
        </div>
      </div>
    </main>
  );
};

export default Home;
