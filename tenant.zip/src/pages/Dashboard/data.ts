export const serviceData = [
  {
    des: " Lorem Ipsum is simply dummy text",
    date: " 10/10/2022",
    status: " completed",
  },
  {
    des: " Lorem Ipsum is simply dummy text",
    date: " 10/10/2022",
    status: " completed",
  },
  {
    des: " Lorem Ipsum is simply dummy text",
    date: " 10/10/2022",
    status: " completed",
  },
];
