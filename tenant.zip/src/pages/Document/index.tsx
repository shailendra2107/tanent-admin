import React from 'react'

const Document = () => {
  return (
    <div>Document</div>
  )
}

export default Document