import React from 'react'

const BankSetup = () => {
  return (
    <div>BankSetup</div>
  )
}

export default BankSetup