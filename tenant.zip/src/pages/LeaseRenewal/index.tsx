import React from 'react'

const LeaseRenewal = () => {
  return (
    <div>LeaseRenewal</div>
  )
}

export default LeaseRenewal