import React from 'react'

const Deliveries = () => {
  console.log("first")
  return (
    <div>Deliveries</div>
  )
}

export default Deliveries