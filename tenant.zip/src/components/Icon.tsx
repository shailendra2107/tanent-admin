import React from 'react'
import SVG from "react-inlinesvg";
import { IconProps } from '../models/interface';



const Icon = ({
  src,
  fill,
  classNames
}: IconProps) => {
  return (
    <>
      <SVG src={src} fill={fill} height={"auto"} />

    </>
  )
}

export default Icon