import SVG from 'react-inlinesvg';
import view from '../../assets/Icons/view.svg'

export const ServiceRequest: any[] = [
  {
    dataField: 'des',
    caption: 'Description',
    cssClass: "px-10",
  },
  {
    dataField: 'date',
    caption: 'Date',
    cssClass: "px-10",
    width: 120
  },

  {
    dataField: 'status',
    caption: 'status',
    cssClass: "px-10",
    width: 120,
    cellRender: (cellData: any) => {
      return (
        <label className="font_13 text_green bg_light_green p-1 flex items-center justify-center rounded-sm  font-bold">
          {cellData.data.status}
        </label>
      )
    },
  },
  {
    dataField: '',
    caption: 'view details',
    width: 150,
    cssClass: 'text_center',
    cellRender: (cellData: any) => {
      return (
        <div className="flex justify-center">
          <SVG
            src={view}
            width={24} height="auto" />
        </div>
      )
    },
  },
];