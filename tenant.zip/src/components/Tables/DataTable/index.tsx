import * as React from 'react';
import DataGrid, {
  Column,
  Grouping,
  GroupPanel,
  Pager,
  Paging,
  SearchPanel,
} from 'devextreme-react/data-grid';



const DataTable = ({
  columns,
  isEditMode,
  loading,
  pageSize,
  ...props
}: any) => {
  console.log('props.dataSource :>> ', props.dataSource);
  return (
    <DataGrid
      dataSource={props.dataSource}
      {...props}
      showRowLines={true}
      showColumnLines={false}
      showBorders={false}
      height="auto"

    >
      {columns?.map((column: any, idx: any) => {
        console.log('column :>> ', column);
        if (column?.cellRender) {
          return (
            <Column
              key={idx}
              width={column.width}
              caption={column.caption}
              cssClass={column.cssClass}
              dataField={column.dataField}
              cellRender={(cellData: any) => column.cellRender(cellData)}
            />
          );
        } else {
          return (
            <Column
              key={idx}
              width={column.width}
              caption={column.caption}
              cssClass={column.cssClass}
              dataField={column.dataField}
              allowResizing={!!column.allowResizing}
            />
          )
        }

      })}
      <Paging defaultPageSize={5} />
      <Pager
        showInfo={true}
        showNavigationButtons
        visible={true}
      />
    </DataGrid>
  );
};

export default DataTable;
