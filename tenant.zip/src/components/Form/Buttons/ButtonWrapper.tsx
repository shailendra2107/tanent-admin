import React from 'react'
import SVG, { Props as SVGProps } from 'react-inlinesvg';
export interface IButtonProps {
  classNames?: string;
  svgIcon?: any;
  text?: string;
  onHandleClick?: () => void;
}

export interface ButtonProps extends IButtonProps, React.ButtonHTMLAttributes<HTMLButtonElement> {

}
const ButtonWrapper = ({
  classNames,
  type, svgIcon, text, onHandleClick
}: ButtonProps) => {
  return (
    <>
      <button
        className={classNames}
        type={type}
        onClick={onHandleClick}
      >
        {
          svgIcon &&
          <div className="mr-2">
            <SVG
              src={svgIcon}
              width={24} height="auto" />
          </div>
        }
        <span>{text}</span>
      </button>
    </>
  )
}

export default ButtonWrapper