import { SelectBox } from 'devextreme-react'
import React from 'react'
import { ISelectProps } from '../../../models/interface'

const Select = ({
  items,
  value,
  classNames,
  onHandleChange,
  label,
  mode
}: ISelectProps) => {
  return (
    <div className={classNames}>
      <SelectBox
        labelMode={mode}
        label={label}
        items={items}
        value={value}
        onValueChanged={onHandleChange}
        displayExpr="name"
        valueExpr="Id"
      />
    </div>
  )
}

export default Select