import React from 'react'
import DateBox from 'devextreme-react/date-box';
import { IDateProps, InputProps } from '../../../models/interface';


const DatePicker = ({
  classNames
}: InputProps) => {
  // console.log('type :>> ', type);
  return (
    <div className={classNames}>
      <DateBox defaultValue={new Date()}
        type='date' />
    </div>
  )
}

export default DatePicker