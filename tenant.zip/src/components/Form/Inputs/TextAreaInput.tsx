import React from 'react'
import TextArea from 'devextreme-react/text-area';
import { ITextAreaProps } from '../../../models/interface';
import dxTextArea from 'devextreme/ui/text_area';

export interface TextProps extends ITextAreaProps, dxTextArea { }

const TextAreaInput = ({
  maxLength,
  height,
  mode,
  label,
  value
  // name
}: TextProps) => {
  return (
    <div>
      <TextArea
        // name={name}
        value={value}
        label={label}
        labelMode={mode}
        height={height}
        maxLength={maxLength}
      // defaultValue={this.state.value} 
      />
    </div>
  )
}

export default TextAreaInput