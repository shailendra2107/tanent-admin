import React, { useState } from "react";
import { TextBox, Button as TextBoxButton } from "devextreme-react/text-box";
import viewIcon from "../../../assets/Icons/view.svg";
import { InputProps } from "../../../models/interface";
import SVG from "react-inlinesvg";

const InputWrapper: React.FC<InputProps> = ({
  placeholder,
  name,
  value,
  error,
  type,
  onHandleChange,
}) => {
  const [show, setShow] = useState<boolean>(false);
  const passwordButton = {
    icon: viewIcon,
    type: "default",
    onClick: () => {
      setShow(!show);
    },
  };
  return (
    <>
      {/* <TextBox
        placeholder={placeholder}
        name={name}
        value={value}
        onValueChanged={onHandleChange}
        mode={!show ? 'text' : mode}
      >
        <TextBoxButton
          name="password"
          location="after"
          options={passwordButton}

        />
      </TextBox> */}
      <div className="border outLine rounded-md  flex p-[5px]">
        <input
          className="bg-transparent border-none flex-1 focus:outline-none px-2 placeholder:text-sm text-sm placeholder:font-normal text-purple font-medium"
          type={type === "password" ? (show ? "text" : "password") : type}
          name={name}
          placeholder={placeholder}
          value={value}
          onChange={onHandleChange}
        />
        {placeholder === "password" && (
          <div
            className="cursor-pointer flex items-center mx-1 text-lightGray"
            onClick={() => setShow(!show)}
          >
            <SVG src={viewIcon} color={"text-lightGray"} />
          </div>
        )}
      </div>
      {error && <label className="absolute top-0 left-0">{error}</label>}
    </>
  );
};

export default InputWrapper;
