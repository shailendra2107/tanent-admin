import React from 'react'
import Select from '../../components/Form/Inputs/Select'
import Icon from '../../components/Icon'
import notification from '../../assets/Icons/notifications.svg'

const NavHeader = () => {

  const items = [
    {
      name: "English",
      Id: 1
    },
    {
      name: "Spanish",
      Id: 2
    },
    {
      name: "Hindi",
      Id: 3
    },
  ]
  return (
    <>
      <div className="bg-white px-4 py-2">
        <div className="w-full flex items-center justify-between">
          <div className="logo">Logo</div>
          <div className="flex">
            <div className="">
              <Select items={items} classNames='w-32' />
            </div>
            <div className="mx-3 flex items-center">
              <Icon src={notification} />
            </div>
            <div className="rounded-full bg-slate-300 w-10 h-10 flex items-center justify-center">
              JD
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default NavHeader