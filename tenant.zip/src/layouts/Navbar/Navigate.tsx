import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import Icon from '../../components/Icon';
import { routes } from '../../router/routes';

const Navigate = () => {
  const location = useLocation()
  return (
    <div className='bg-dark-purple p-2 shadow-purple'>
      <ul className='flex justify-around'>
        {
          routes.map((item, i) => {
            return (
              <li className={`${location.pathname === item.path ? 'bg-white' : "bg-transparent"} font-medium px-4 py-1 rounded-md`}>
                <Link to={item.path} >
                  <div className="flex">
                    <div className="">
                      <Icon
                        src={item.icon} fill={location.pathname === item.path ? "red" : "white"}
                      />
                    </div>
                    <div className={`${location.pathname === item.path ? 'text-dark-purple' : 'text-white'}`}>{item.title}</div>
                  </div>
                </Link>
              </li>
            )
          })
        }

      </ul>
    </div>
  )
}

export default Navigate