import type { RouteProps } from "react-router-dom";

import DashboardIcon from "../assets/Icons/menuIcon/bar_chart.svg";
import BankIcon from "../assets/Icons/menuIcon/bank-setup.svg";
import DeliveryIcon from "../assets/Icons/menuIcon/delivery-parcel.svg";
import DocumentIcon from "../assets/Icons/menuIcon/document.svg";
import HelpIcon from "../assets/Icons/menuIcon/help.svg";
import RenewalIcon from "../assets/Icons/menuIcon/lease-renewal.svg";
import ServicesIcon from "../assets/Icons/menuIcon/services-request.svg";

import Dashboard from "../pages/Dashboard";
import BankSetup from "../pages/BankSetup";
import Deliveries from "../pages/Deliveries";
import Document from "../pages/Document";
import Help from "../pages/Help";
import LeaseRenewal from "../pages/LeaseRenewal";
import ServiceRequest from "../pages/ServiceRequest";

export interface IRoute extends Omit<RouteProps, "component"> {
  path: string;
  title: string;
  component: string;
  icon: string;
}

export const routes = [
  {
    path: "/dashboard",
    title: "Dashboards",
    component: Dashboard,
    icon: DashboardIcon,
  },
  {
    path: "/deliveries",
    title: "Deliveries",
    component: Deliveries,
    icon: DeliveryIcon,
  },
  {
    path: "/services-request",
    title: "Services Request",
    component: ServiceRequest,
    icon: ServicesIcon,
  },
  {
    path: "/lease-renewal",
    title: "Lease Renewal",
    component: LeaseRenewal,
    icon: RenewalIcon,
  },
  {
    path: "/document",
    title: "Documents",
    component: Document,
    icon: DocumentIcon,
  },
  {
    path: "/bank-setup",
    title: "Bank Setup",
    component: BankSetup,
    icon: BankIcon,
  },
  {
    path: "/help",
    title: "Help",
    component: Help,
    icon: HelpIcon,
  },
];
